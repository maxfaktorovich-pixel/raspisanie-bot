/**
 * Schedule logic for МАОУ «Гимназия №3 в Академгородке».
 * Port of /home/box/gym3/tgbot.py — same commands and HTML formatting.
 * Dates use a fixed Asia/Novosibirsk offset (UTC+7, no DST).
 */

export const SCHOOL = "МАОУ «Гимназия №3 в Академгородке»";
export const SCHEDULE_PAGE = "https://raspisanie.nikasoft.ru/90311972.html";
export const SCHEDULE_BASE = "https://raspisanie.nikasoft.ru/static/public/";
export const CACHE_TTL_SECONDS = 10 * 60;
export const NSK_OFFSET_MS = 7 * 60 * 60 * 1000;
export const CACHE_KEY_URL = "https://cache.internal/nika.json";

const LETTER_MAP = {
  a: "а", b: "б", v: "в", g: "г", d: "д", e: "е",
  c: "с", o: "о", p: "р", x: "х", y: "у", k: "к",
  m: "м", t: "т", h: "н",
};

const SUBJECT_EXPAND = {
  "русс.яз.": "русский язык",
  "русс.": "русский язык",
  "физ-ра": "физкультура",
  "матем.": "математика",
  "лит-ра": "литература",
  "введ.в инф.": "введение в информатику",
  "введ.в.инф.": "введение в информатику",
  "англ.яз.": "английский язык",
  "англ.": "английский язык",
  "биол.": "биология",
  "геогр.": "география",
  "геом.": "геометрия",
  "истор": "история",
  "обществ.": "обществознание",
  "инф.": "информатика",
  "инф.тех.": "информационные технологии",
  "экон.": "экономика",
  "окр. мир": "окружающий мир",
  "класс.час": "классный час",
  "внеурочн.вр.": "внеурочная деятельность",
  "шк.франц.": "французский язык",
  "шк.нем.": "немецкий язык",
  "межд.франц.": "французский язык",
  "межд.нем": "немецкий язык",
  "введ.в инж.": "введение в инженерию",
  "введ.в.инж.": "введение в инженерию",
  "введ.в экон.": "введение в экономику",
  "введ.в.экон.": "введение в экономику",
  "лит.чтение": "литературное чтение",
  "литературное чтение": "литературное чтение",
};

const WEEKDAYS = {
  понедельник: 1, пн: 1,
  вторник: 2, вт: 2,
  среда: 3, ср: 3,
  четверг: 4, чт: 4,
  пятница: 5, пт: 5,
  суббота: 6, сб: 6,
  воскресенье: 7, вс: 7,
};

const DATE_RE = /(?<![0-9])(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?(?![0-9])/u;
const CLASS_RE = /(?<![\p{L}\p{N}_])(\d{1,2})([a-zа-яё])(?![\p{L}\p{N}_])/giu;
const CMD_RE = /^\/([a-zA-Z_]+)(?:@[\w_]+)?(?:\s+|$)/;

function translitLetter(ch) {
  const low = ch.toLowerCase();
  return LETTER_MAP[low] || low;
}

export function esc(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

export function arr(v) {
  if (v == null) return [];
  return Array.isArray(v) ? v : [v];
}

export function clean(s) {
  if (!s) return "";
  let t = String(s);
  t = t.replace(/^\(н\)/, "");
  t = t.replace(/^\((вн|кр)\)/, "");
  t = t.replace(/_[^/]*\s*\/\S+\s*$/, "");
  return t.trim();
}

export function prettySubject(name) {
  const raw = clean(name);
  return SUBJECT_EXPAND[raw.toLowerCase()] || raw;
}

/** Instant whose Novosibirsk wall-clock is the given local time. */
export function fromNsk(year, month, day, hour = 12, minute = 0) {
  return new Date(Date.UTC(year, month - 1, day, hour - 7, minute, 0));
}

export function nowNsk(now = new Date()) {
  const t = new Date(now.getTime() + NSK_OFFSET_MS);
  return fromNsk(
    t.getUTCFullYear(),
    t.getUTCMonth() + 1,
    t.getUTCDate(),
    t.getUTCHours(),
    t.getUTCMinutes(),
  );
}

function nskParts(dt) {
  const t = new Date(dt.getTime() + NSK_OFFSET_MS);
  return {
    year: t.getUTCFullYear(),
    month: t.getUTCMonth() + 1,
    day: t.getUTCDate(),
    hour: t.getUTCHours(),
    minute: t.getUTCMinutes(),
    weekday: t.getUTCDay(), // 0=Sun
  };
}

export function fmtDate(dt) {
  const p = nskParts(dt);
  const dd = String(p.day).padStart(2, "0");
  const mm = String(p.month).padStart(2, "0");
  return `${dd}.${mm}.${p.year}`;
}

export function dowOf(dt) {
  const w = nskParts(dt).weekday;
  return w === 0 ? 7 : w;
}

export function addDays(dt, n) {
  return new Date(dt.getTime() + n * 86400000);
}

export function setNskTime(dt, hour, minute = 0) {
  const p = nskParts(dt);
  return fromNsk(p.year, p.month, p.day, hour, minute);
}

export function dateTitle(nika, dt) {
  const days = nika?.DAY_NAMES || [
    "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье",
  ];
  const months = nika?.MONTHS2 || [
    "января", "февраля", "марта", "апреля", "мая", "июня",
    "июля", "августа", "сентября", "октября", "ноября", "декабря",
  ];
  const p = nskParts(dt);
  let month = months[p.month - 1] || "";
  if (month && month[0] === month[0].toUpperCase()) month = month.toLowerCase();
  const dowName = String(days[dowOf(dt) - 1] || "").toLowerCase();
  return `${dowName}, ${p.day} ${month}`;
}

export function parseDateToken(day, month, year, today) {
  try {
    if (year == null) {
      const ty = nskParts(today).year;
      let cand = fromNsk(ty, month, day, 12, 0);
      const todayDate = setNskTime(today, 12, 0);
      if (setNskTime(cand, 12, 0) < addDays(todayDate, -7)) {
        cand = fromNsk(ty + 1, month, day, 12, 0);
      }
      return cand;
    }
    if (year < 100) year += 2000;
    return fromNsk(year, month, day, 12, 0);
  } catch {
    return null;
  }
}

export function nextWeekday(today, targetDow) {
  const cur = dowOf(today);
  const delta = (targetDow - cur + 7) % 7;
  return setNskTime(addDays(today, delta), 12, 0);
}

export function periodId(nika, dt) {
  const periods = nika?.PERIODS || {};
  const target = setNskTime(dt, 12, 0);
  for (const [p, rec] of Object.entries(periods)) {
    if (!rec?.b || !rec?.e) continue;
    const [bd, bm, by] = rec.b.split(".");
    const [ed, em, ey] = rec.e.split(".");
    const start = fromNsk(+by, +bm, +bd, 12, 0);
    const end = fromNsk(+ey, +em, +ed, 12, 0);
    if (start <= target && target <= end) return p;
  }
  return null;
}

export function classIdsByName(nika) {
  const out = {};
  for (const [cid, name] of Object.entries(nika?.CLASSES || {})) {
    const n = clean(name).toLowerCase();
    if (/^\d{1,2}[а-яё]$/u.test(n)) out[n] = cid;
  }
  return out;
}

export function findClasses(nika, names) {
  const mapping = classIdsByName(nika);
  const found = [];
  const missing = [];
  for (const raw of names) {
    const key = String(raw)
      .toLowerCase()
      .replace(/[a-z]/g, translitLetter);
    const cid = mapping[key];
    if (cid) found.push([clean(nika.CLASSES[cid]), cid]);
    else missing.push(raw);
  }
  return { found, missing };
}

export function findTeachers(nika, query) {
  let q = clean(query).toLowerCase().trim().replace(/\s+/g, " ");
  if (!q) return [];
  const exact = [];
  const starts = [];
  const contains = [];
  for (const [tid, name] of Object.entries(nika?.TEACHERS || {})) {
    const disp = clean(name);
    const low = disp.toLowerCase();
    const last = low.split(/\s+/)[0] || "";
    if (low === q || last === q) exact.push([disp, tid]);
    else if (low.startsWith(q) || last.startsWith(q)) starts.push([disp, tid]);
    else if (low.includes(q)) contains.push([disp, tid]);
  }
  return exact.length ? exact : starts.length ? starts : contains;
}

export function lessonEntry(base, exch, dow, lesson) {
  const key = String(dow * 100 + lesson);
  const bag = exch || {};
  let ch = bag[String(lesson)];
  if (ch === undefined) ch = bag[lesson];
  const e = ch !== undefined && ch !== null ? ch : (base || {})[key];
  return { e, changed: ch !== undefined && ch !== null };
}

export function isCancelled(e) {
  if (!e) return false;
  const s = e.s;
  return s === "F" || (Array.isArray(s) && s.length === 1 && s[0] === "F");
}

export function formatClassLesson(nika, e, changed) {
  if (isCancelled(e)) {
    const mark = changed ? "  <i>замена, отменён</i>" : "  <i>отменён</i>";
    return `урок отменён${mark}`;
  }
  const subjects = arr(e.s);
  const teachers = arr(e.t);
  const rooms = arr(e.r);
  const groups = arr(e.g);
  const parts = [];
  for (let i = 0; i < subjects.length; i++) {
    const sid = subjects[i];
    const subj = prettySubject((nika.SUBJECTS || {})[sid] ?? sid);
    const tid = i < teachers.length ? teachers[i] : "";
    const tname = tid ? clean((nika.TEACHERS || {})[tid] ?? tid) : "";
    const rid = i < rooms.length ? rooms[i] : "";
    const room = rid ? (nika.ROOMS || {})[rid] ?? rid : "";
    let gname = "";
    if (i < groups.length && groups[i] != null) {
      const g = groups[i];
      gname = (nika.CLASSGROUPS || {})[String(g)] || (nika.CLASSGROUPS || {})[g] || "";
    }
    let line = esc(subj);
    const extra = [];
    if (tname) extra.push(esc(tname));
    if (room) extra.push(`каб. ${esc(String(room))}`);
    if (extra.length) line += " — " + extra.join(", ");
    if (gname) line = `${esc(gname)}: ${line}`;
    parts.push(line);
  }
  let body = parts.length > 1 ? parts.join("\n") : (parts[0] || "");
  if (changed) body += "  <i>замена</i>";
  return body;
}

export function formatTeacherLesson(nika, e, changed) {
  if (isCancelled(e)) {
    const mark = changed ? "  <i>замена, отменён</i>" : "  <i>отменён</i>";
    return `урок отменён${mark}`;
  }
  const subj = prettySubject((nika.SUBJECTS || {})[e.s] ?? e.s ?? "");
  const classes = arr(e.c)
    .map((c) => clean((nika.CLASSES || {})[c] ?? c))
    .join(", ");
  const room = e.r ? (nika.ROOMS || {})[e.r] ?? e.r : "";
  const bits = [esc(subj)];
  if (classes) bits.push(esc(classes));
  if (room) bits.push(`каб. ${esc(String(room))}`);
  let body = bits.join(" — ");
  if (changed) body += "  <i>замена</i>";
  return body;
}

export function dayLessons(nika, cid, dt, isTeacher = false) {
  const per = periodId(nika, dt);
  if (!per) return { err: "Нет активного периода расписания на эту дату.", items: [] };
  const schedRoot = (isTeacher ? nika.TEACH_SCHEDULE : nika.CLASS_SCHEDULE) || {};
  const exchRoot = (isTeacher ? nika.TEACH_EXCHANGE : nika.CLASS_EXCHANGE) || {};
  const base = ((schedRoot[String(per)] || schedRoot[per]) || {})[cid] || {};
  const ds = fmtDate(dt);
  const exch = ((exchRoot[cid] || {})[ds]) || {};
  const dow = dowOf(dt);
  const times = nika.LESSON_TIMES || {};
  const nless = Number(nika.LESSONSINDAY || 8);
  const items = [];
  for (let l = 1; l <= nless; l++) {
    const { e, changed } = lessonEntry(base, exch, dow, l);
    if (!e) continue;
    const tm = times[String(l)] || times[l] || ["", ""];
    const tspan = tm.length >= 2 ? `${tm[0]}–${tm[1]}` : "";
    const body = isTeacher
      ? formatTeacherLesson(nika, e, changed)
      : formatClassLesson(nika, e, changed);
    items.push({ num: l, tspan, body, changed });
  }
  return { err: null, items };
}

export function renderDay(nika, titleLeft, dt, items, err, kind = "класса") {
  const head = `<b>${esc(titleLeft)} — ${esc(dateTitle(nika, dt))}</b>`;
  if (err) return `${head}\n\n${esc(err)}`;
  if (dowOf(dt) === 7 && (!items || !items.length)) {
    return `${head}\n\nВ воскресенье у ${esc(kind)} уроков нет — гимназия отдыхает.`;
  }
  if (!items || !items.length) return `${head}\n\nВ этот день уроков нет.`;
  const lines = [head, ""];
  for (const { num, tspan, body } of items) {
    if (body.includes("\n")) {
      lines.push(`<b>${num}.</b> ${esc(tspan)}`);
      for (const part of body.split("\n")) lines.push(part);
    } else {
      lines.push(`<b>${num}.</b> ${esc(tspan)} — ${body}`);
    }
  }
  return lines.join("\n");
}

export function renderWeek(nika, name, cid, today, isTeacher = false) {
  const dow = dowOf(today);
  let start = addDays(today, -(dow - 1));
  if (dow === 7) start = addDays(today, 1);
  start = setNskTime(start, 12, 0);
  const sp = nskParts(start);
  const blocks = [
    `<b>${esc(name)} — неделя с ${String(sp.day).padStart(2, "0")}.${String(sp.month).padStart(2, "0")}</b>`,
  ];
  for (let i = 0; i < 6; i++) {
    const dt = addDays(start, i);
    const { err, items } = dayLessons(nika, cid, dt, isTeacher);
    if (err) {
      blocks.push(`\n<b>${esc(dateTitle(nika, dt))}</b>\n${esc(err)}`);
      continue;
    }
    if (!items.length) {
      blocks.push(`\n<b>${esc(dateTitle(nika, dt))}</b>\nуроков нет`);
      continue;
    }
    const lines = [`\n<b>${esc(dateTitle(nika, dt))}</b>`];
    for (const { num, tspan, body } of items) {
      const one = body.replace(/\n/g, " / ");
      lines.push(`<b>${num}.</b> ${esc(tspan)} — ${one}`);
    }
    blocks.push(lines.join("\n"));
  }
  return blocks.join("\n");
}


/** JS \b does not treat Cyrillic as word characters; use this instead. */
function cyrWordRe(inner, flags = "iu") {
  return new RegExp(`(?<![а-яёa-z])(?:${inner})(?![а-яёa-z])`, flags);
}

export function extractWhen(text, today) {
  let raw = text;
  let wantWeek = false;
  if (cyrWordRe("на\\s+неделю|неделя|неделю").test(raw)) {
    wantWeek = true;
    raw = raw.replace(cyrWordRe("на\\s+неделю|неделя|неделю", "giu"), " ");
  }
  if (cyrWordRe("сегодня").test(raw)) {
    raw = raw.replace(cyrWordRe("сегодня", "giu"), " ");
    return { dt: today, wantWeek, rest: raw };
  }
  if (cyrWordRe("завтра").test(raw)) {
    raw = raw.replace(cyrWordRe("завтра", "giu"), " ");
    return { dt: addDays(today, 1), wantWeek, rest: raw };
  }
  if (cyrWordRe("вчера").test(raw)) {
    raw = raw.replace(cyrWordRe("вчера", "giu"), " ");
    return { dt: addDays(today, -1), wantWeek, rest: raw };
  }
  const m = DATE_RE.exec(raw);
  if (m) {
    const dt = parseDateToken(+m[1], +m[2], m[3] ? +m[3] : null, today);
    raw = raw.slice(0, m.index) + " " + raw.slice(m.index + m[0].length);
    return { dt, wantWeek, rest: raw };
  }
  const low = raw.toLowerCase();
  const words = Object.keys(WEEKDAYS).sort((a, b) => b.length - a.length);
  for (const word of words) {
    const re = new RegExp(`(?<![а-яёa-z])${word}(?![а-яёa-z])`, "iu");
    if (re.test(low)) {
      raw = raw.replace(re, " ");
      return { dt: nextWeekday(today, WEEKDAYS[word]), wantWeek, rest: raw };
    }
  }
  return { dt: null, wantWeek, rest: raw };
}

export function extractClassNames(text) {
  const names = [];
  const re = new RegExp(CLASS_RE.source, CLASS_RE.flags);
  let m;
  while ((m = re.exec(text))) {
    names.push(m[1] + translitLetter(m[2]));
  }
  const seen = new Set();
  const out = [];
  for (const n of names) {
    if (!seen.has(n)) {
      seen.add(n);
      out.push(n);
    }
  }
  return out;
}

function knownClassesList(nika) {
  const names = Object.keys(classIdsByName(nika));
  names.sort((a, b) => {
    const na = parseInt(a, 10);
    const nb = parseInt(b, 10);
    if (na !== nb) return na - nb;
    return a.localeCompare(b, "ru");
  });
  return names.join(", ");
}

export function classScheduleReply(nika, names, dt, wantWeek, today) {
  const { found, missing } = findClasses(nika, names);
  const bits = [];
  if (missing.length) {
    bits.push("Не найден класс: " + missing.map(esc).join(", ") + ".");
    bits.push("Доступны: " + esc(knownClassesList(nika)));
  }
  if (!found.length) {
    return bits.length ? bits.join("\n") : "Укажите класс, например 5а.";
  }
  if (wantWeek) {
    const parts = found.map(([name, cid]) => renderWeek(nika, name, cid, today, false));
    return (bits.length ? bits.concat(parts) : parts).join("\n\n");
  }
  if (dt == null) dt = today;
  const parts = found.map(([name, cid]) => {
    const { err, items } = dayLessons(nika, cid, dt, false);
    return renderDay(nika, name, dt, items, err, name);
  });
  return (bits.length ? bits.concat(parts) : parts).join("\n\n");
}

export function teacherReply(nika, query, dt, wantWeek, today) {
  query = (query || "").trim();
  if (!query) return "Укажите фамилию учителя: /teacher Кадулин";
  const matches = findTeachers(nika, query);
  if (!matches.length) return `Учитель «${esc(query)}» не найден.`;
  if (matches.length > 1) {
    const names = matches.slice(0, 15).map(([n]) => `• ${esc(n)}`).join("\n");
    return `Несколько совпадений по «${esc(query)}» — уточните:\n${names}`;
  }
  const [name, tid] = matches[0];
  if (wantWeek) return renderWeek(nika, name, tid, today, true);
  if (dt == null) dt = today;
  const { err, items } = dayLessons(nika, tid, dt, true);
  return renderDay(nika, name, dt, items, err, "учителя");
}

export function helpText() {
  return (
    `<b>Расписание ${esc(SCHOOL)}</b>\n` +
    "Новосибирск, данные с raspisanie.nikasoft.ru\n\n" +
    "<b>Команды</b>\n" +
    "/today 5а — расписание на сегодня\n" +
    "/tomorrow 5а — на завтра\n" +
    "/schedule 5а — тоже на сегодня\n" +
    "/schedule 5а 23.11 — на дату\n" +
    "/week 5а — вся неделя (пн–сб)\n" +
    "/teacher Кадулин — расписание учителя\n" +
    "/teacher Кадулин завтра\n" +
    "/myclass 5а — запомнить класс\n" +
    "/subscribe 5а — присылать замены в 7:45\n" +
    "/unsubscribe — отменить рассылку\n" +
    "/help — эта справка\n\n" +
    "Можно писать обычным текстом:\n" +
    "«5а сегодня», «расписание 5а», «5а завтра»,\n" +
    "«5а понедельник», «5а 7б завтра».\n\n" +
    "После /myclass достаточно написать «сегодня» или «завтра».\n" +
    "Если написать только /myclass, класс можно прислать следующим сообщением."
  );
}

export function startText() {
  return `Привет! Я бот расписания ${esc(SCHOOL)}.\n\n` + helpText();
}

export function parseNikaSource(src) {
  const text = String(src || "").replace(/^\uFEFF/, "");
  const marker = "var NIKA=";
  const i = text.indexOf(marker);
  if (i < 0) throw new Error("var NIKA= not found in schedule JS");
  let body = text.slice(i + marker.length).trim();
  if (body.endsWith(";")) body = body.slice(0, -1).trim();
  return JSON.parse(body);
}

export async function fetchNika(fetchFn = globalThis.fetch) {
  const htmlRes = await fetchFn(SCHEDULE_PAGE);
  if (!htmlRes.ok) throw new Error(`schedule html HTTP ${htmlRes.status}`);
  const html = await htmlRes.text();
  const m = html.match(/static\/public\/(90311972_\d+\.js)/);
  if (!m) throw new Error("no schedule js reference in html");
  const jsRes = await fetchFn(SCHEDULE_BASE + m[1]);
  if (!jsRes.ok) throw new Error(`schedule js HTTP ${jsRes.status}`);
  const src = await jsRes.text();
  const nika = parseNikaSource(src);
  if (!nika || !nika.CLASSES) throw new Error("failed to parse NIKA");
  return nika;
}

function cacheRequest() {
  return new Request(CACHE_KEY_URL, { method: "GET" });
}

export async function getNika(opts = {}) {
  if (opts.nika) return opts.nika;
  const cache = opts.cache ?? globalThis.caches?.default;
  const fetchFn = opts.fetch ?? globalThis.fetch;
  const key = cacheRequest();
  if (cache && typeof cache.match === "function") {
    try {
      const hit = await cache.match(key);
      if (hit) return await hit.json();
    } catch {
      // Cache API may be unavailable off-zone; fetch fresh.
    }
  }
  const nika = await fetchNika(fetchFn);
  if (cache && typeof cache.put === "function") {
    try {
      await cache.put(
        key,
        new Response(JSON.stringify(nika), {
          headers: {
            "Content-Type": "application/json",
            "Cache-Control": `public, max-age=${CACHE_TTL_SECONDS}`,
          },
        }),
      );
    } catch {
      // ignore cache write failures
    }
  }
  return nika;
}

export class MemoryKV {
  constructor() {
    this.map = new Map();
    this.exp = new Map();
  }
  _alive(key) {
    const exp = this.exp.get(key);
    if (exp && Date.now() > exp) {
      this.map.delete(key);
      this.exp.delete(key);
      return false;
    }
    return this.map.has(key);
  }
  async get(key) {
    if (!this._alive(key)) return null;
    return this.map.get(key);
  }
  async put(key, value, opts = {}) {
    this.map.set(key, value);
    if (opts.expirationTtl) this.exp.set(key, Date.now() + opts.expirationTtl * 1000);
    else this.exp.delete(key);
  }
  async delete(key) {
    this.map.delete(key);
    this.exp.delete(key);
  }
  async list({ prefix = "" } = {}) {
    const keys = [];
    for (const name of this.map.keys()) {
      if (name.startsWith(prefix) && this._alive(name)) keys.push({ name });
    }
    return { keys };
  }
}

export class MemoryCache {
  constructor() {
    this.store = new Map();
  }
  async match(req) {
    const url = typeof req === "string" ? req : req.url;
    const e = this.store.get(url);
    if (!e) return undefined;
    if (Date.now() > e.exp) {
      this.store.delete(url);
      return undefined;
    }
    return new Response(e.body, { headers: { "Content-Type": "application/json" } });
  }
  async put(req, res) {
    const url = typeof req === "string" ? req : req.url;
    const body = await res.clone().text();
    this.store.set(url, { body, exp: Date.now() + CACHE_TTL_SECONDS * 1000 });
  }
}

async function kvGet(kv, key) {
  if (!kv || typeof kv.get !== "function") return null;
  try {
    return await kv.get(key);
  } catch {
    return null;
  }
}

async function kvPut(kv, key, value, opts) {
  if (!kv || typeof kv.put !== "function") return false;
  try {
    await kv.put(key, value, opts);
    return true;
  } catch {
    return false;
  }
}

async function kvDelete(kv, key) {
  if (!kv || typeof kv.delete !== "function") return false;
  try {
    await kv.delete(key);
    return true;
  } catch {
    return false;
  }
}

async function kvList(kv, prefix) {
  if (!kv || typeof kv.list !== "function") return [];
  try {
    const out = [];
    let cursor;
    do {
      const page = await kv.list({ prefix, cursor });
      out.push(...(page.keys || []));
      cursor = page.list_complete ? undefined : page.cursor;
    } while (cursor);
    return out;
  } catch {
    return [];
  }
}

function favKey(chatId) {
  return `fav:${chatId}`;
}
function pendingKey(chatId) {
  return `pending:${chatId}`;
}
function subKey(className) {
  return `sub:${className}`;
}

async function getFavorite(kv, chatId) {
  if (chatId == null) return null;
  return (await kvGet(kv, favKey(chatId))) || null;
}

async function setFavorite(kv, chatId, className) {
  return kvPut(kv, favKey(chatId), className);
}

async function getPending(kv, chatId) {
  if (chatId == null) return null;
  return (await kvGet(kv, pendingKey(chatId))) || null;
}

async function setPending(kv, chatId, value) {
  return kvPut(kv, pendingKey(chatId), value, { expirationTtl: 600 });
}

async function clearPending(kv, chatId) {
  return kvDelete(kv, pendingKey(chatId));
}

async function readChatIds(kv, className) {
  const raw = await kvGet(kv, subKey(className));
  if (!raw) return [];
  try {
    const arrIds = JSON.parse(raw);
    return Array.isArray(arrIds) ? arrIds : [];
  } catch {
    return [];
  }
}

async function writeChatIds(kv, className, ids) {
  const uniq = [...new Set(ids.map(String))];
  if (!uniq.length) return kvDelete(kv, subKey(className));
  return kvPut(kv, subKey(className), JSON.stringify(uniq));
}

export async function subscribeChat(kv, chatId, className) {
  if (!kv) return false;
  const ids = await readChatIds(kv, className);
  if (!ids.map(String).includes(String(chatId))) ids.push(String(chatId));
  return writeChatIds(kv, className, ids);
}

export async function unsubscribeChat(kv, chatId, className = null) {
  if (!kv) return [];
  const removed = [];
  if (className) {
    const ids = (await readChatIds(kv, className)).filter((id) => String(id) !== String(chatId));
    await writeChatIds(kv, className, ids);
    removed.push(className);
    return removed;
  }
  const keys = await kvList(kv, "sub:");
  for (const { name } of keys) {
    const cls = name.slice(4);
    const ids = await readChatIds(kv, cls);
    if (ids.map(String).includes(String(chatId))) {
      await writeChatIds(kv, cls, ids.filter((id) => String(id) !== String(chatId)));
      removed.push(cls);
    }
  }
  return removed;
}

export async function listSubscribedClasses(kv) {
  const keys = await kvList(kv, "sub:");
  const out = [];
  for (const { name } of keys) {
    const className = name.slice(4);
    const chats = await readChatIds(kv, className);
    if (chats.length) out.push({ className, chats });
  }
  return out;
}

export function dayHasChanges(items) {
  return (items || []).some((it) => it.changed || (it.body && it.body.includes("<i>замена")));
}

export async function changesMessage(nika, className, dt) {
  const { found } = findClasses(nika, [className]);
  if (!found.length) return null;
  const [name, cid] = found[0];
  const { err, items } = dayLessons(nika, cid, dt, false);
  if (err || !dayHasChanges(items)) return null;
  const body = renderDay(nika, name, dt, items, err, name);
  return `<b>Замены на сегодня</b>\n\n${body}`;
}

async function saveClassFavorite(kv, chatId, nika, names, today) {
  const { found } = findClasses(nika, names.slice(0, 1));
  if (!found.length) return { ok: false, text: classScheduleReply(nika, names.slice(0, 1), null, false, today) };
  if (chatId == null) {
    return { ok: false, text: `Класс ${esc(found[0][0])} подходит, но chat_id не задан.` };
  }
  const ok = await setFavorite(kv, chatId, found[0][0]);
  if (!ok) {
    return {
      ok: false,
      text: `Класс <b>${esc(found[0][0])}</b> найден, но запомнить его не получилось (нет KV-привязки FAV).`,
    };
  }
  await clearPending(kv, chatId);
  return {
    ok: true,
    name: found[0][0],
    text: `Запомнила класс <b>${esc(found[0][0])}</b>. Теперь «сегодня» и «завтра» покажут его расписание.`,
  };
}

/**
 * Pure-ish handler: text in, HTML reply out.
 * @returns {Promise<string>}
 */
export async function handleMessage(text, opts = {}) {
  const nika = opts.nika || (await getNika(opts));
  const kv = opts.kv ?? opts.env?.FAV ?? null;
  const chatId = opts.chatId;
  let today = opts.today ? new Date(opts.today) : nowNsk();
  today = nowNsk(today);

  text = String(text || "").trim();
  if (!text) return "Напишите класс, например «5а сегодня». /help — справка.";

  const mcmd = CMD_RE.exec(text);
  const cmd = mcmd ? mcmd[1].toLowerCase() : null;
  const args = mcmd ? text.slice(mcmd[0].length).trim() : text;

  if (cmd === "start") return startText();
  if (cmd === "help" || cmd === "pomoshch") return helpText();

  // A new slash-command cancels a pending /myclass, except /myclass itself.
  if (cmd && cmd !== "myclass" && cmd !== "class") {
    await clearPending(kv, chatId);
  }

  if (cmd === "myclass" || cmd === "class") {
    const names = extractClassNames(args);
    if (!names.length) {
      const fav = await getFavorite(kv, chatId);
      await setPending(kv, chatId, "myclass");
      if (fav) {
        return (
          `Ваш класс: <b>${esc(fav)}</b>. Чтобы сменить, напишите класс следующим сообщением, например 5а, или /myclass 5а.`
        );
      }
      return "Укажите класс следующим сообщением, например 5а — или напишите /myclass 5а.";
    }
    const saved = await saveClassFavorite(kv, chatId, nika, names, today);
    return saved.text;
  }

  if (cmd === "subscribe" || cmd === "podpiska") {
    let names = extractClassNames(args);
    if (!names.length) {
      const fav = await getFavorite(kv, chatId);
      if (fav) names = [fav];
    }
    if (!names.length) return "Укажите класс: /subscribe 5а";
    const { found, missing } = findClasses(nika, names.slice(0, 1));
    if (!found.length) return classScheduleReply(nika, names.slice(0, 1), null, false, today);
    if (chatId == null) return "Подписка возможна только из чата.";
    const ok = await subscribeChat(kv, chatId, found[0][0]);
    if (!ok) return "Подписка недоступна: не настроено хранилище KV (привязка FAV).";
    return `Буду присылать замены для <b>${esc(found[0][0])}</b> каждый день в 7:45 по новосибирскому времени (кроме воскресенья). Отмена: /unsubscribe`;
  }

  if (cmd === "unsubscribe" || cmd === "otpisat") {
    if (chatId == null) return "Отписка возможна только из чата.";
    const names = extractClassNames(args);
    if (names.length) {
      const { found } = findClasses(nika, names.slice(0, 1));
      const cls = found.length ? found[0][0] : names[0];
      const removed = await unsubscribeChat(kv, chatId, cls);
      if (!removed.length) return `Вы не были подписаны на замены ${esc(cls)}.`;
      return `Больше не присылаю замены для <b>${esc(removed[0])}</b>.`;
    }
    const removed = await unsubscribeChat(kv, chatId, null);
    if (!kv) return "Хранилище KV не настроено, подписок нет.";
    if (!removed.length) return "Активных подписок на замены нет.";
    return `Отписала от замен: <b>${esc(removed.join(", "))}</b>.`;
  }

  // Pending /myclass + next message "5а" (optionally with a day).
  const pending = !cmd ? await getPending(kv, chatId) : null;
  if (pending === "myclass") {
    const pendingNames = extractClassNames(text);
    if (pendingNames.length) {
      const saved = await saveClassFavorite(kv, chatId, nika, pendingNames, today);
      const { dt, wantWeek } = extractWhen(text, today);
      const looksLikeSchedule =
        wantWeek ||
        dt != null ||
        cyrWordRe("расписание|сегодня|завтра|вчера|неделя|уроки").test(text);
      if (looksLikeSchedule) {
        const sched = classScheduleReply(nika, pendingNames, dt, wantWeek, today);
        return saved.ok ? `${saved.text}\n\n${sched}` : sched;
      }
      return saved.text;
    }
  }

  let isTeacher = false;
  let wantWeek = cmd === "week";
  let rest = cmd ? args : text;

  if (cmd === "teacher" || cmd === "prep") {
    isTeacher = true;
  } else if (/^\s*(учитель|преподаватель|препод)(?![а-яёa-z])/iu.test(rest)) {
    isTeacher = true;
    rest = rest.replace(/^\s*(учитель|преподаватель|препод)(?![а-яёa-z])[:,]?\s*/iu, "");
  }

  let { dt, wantWeek: weekFlag, rest: rest2 } = extractWhen(rest, today);
  wantWeek = wantWeek || weekFlag;
  rest2 = rest2.replace(cyrWordRe("расписание|уроки|покажи|покажите|на", "giu"), " ");
  rest2 = rest2.replace(/\s+/g, " ").replace(/^[ ,.;]+|[ ,.;]+$/g, "");

  if (cmd === "today") dt = today;
  else if (cmd === "tomorrow") dt = addDays(today, 1);
  else if (cmd === "schedule" || cmd === "sched" || cmd === "raspisanie") {
    if (dt == null) dt = today;
  }

  if (isTeacher) return teacherReply(nika, rest2, dt, wantWeek, today);

  let names = extractClassNames(!cmd ? rest2 : (["today", "tomorrow", "schedule", "week"].includes(cmd) ? args : rest2));
  if (cmd) names = extractClassNames(args).length ? extractClassNames(args) : names;

  if (!names.length && chatId != null) {
    const fav = await getFavorite(kv, chatId);
    if (fav) names = [fav];
  }

  if (!names.length) {
    if (cmd || dt != null || wantWeek) {
      return "Укажите класс, например /today 5а — или сохраните его командой /myclass 5а.";
    }
    return "Не поняла запрос. Напишите класс и день, например «5а завтра».\n\n" + helpText();
  }

  return classScheduleReply(nika, names, dt, wantWeek, today);
}
