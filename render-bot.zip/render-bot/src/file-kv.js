/**
 * Tiny Cloudflare-KV-compatible store backed by a JSON file.
 *
 * On Render's free Web Service the disk is ephemeral: favorites and
 * subscriptions are lost on deploy, restart, or after the service sleeps
 * and a new instance starts. That is acceptable for this port.
 */
import fs from "node:fs";
import path from "node:path";

export class FileKV {
  constructor(filePath) {
    this.filePath = filePath;
    this.map = new Map();
    this.exp = new Map();
    this._queue = Promise.resolve();
    this._load();
  }

  _load() {
    try {
      const raw = fs.readFileSync(this.filePath, "utf8");
      const data = JSON.parse(raw);
      const entries = data.entries && typeof data.entries === "object" ? data.entries : data;
      for (const [key, rec] of Object.entries(entries)) {
        if (rec && typeof rec === "object" && "value" in rec) {
          this.map.set(key, rec.value);
          if (rec.exp) this.exp.set(key, rec.exp);
        } else {
          this.map.set(key, rec);
        }
      }
    } catch (err) {
      if (err && err.code !== "ENOENT") {
        console.error(JSON.stringify({ message: "FileKV load failed", error: err.message }));
      }
    }
  }

  _persistSync() {
    const entries = {};
    for (const [key, value] of this.map) {
      if (!this._alive(key)) continue;
      entries[key] = { value };
      const exp = this.exp.get(key);
      if (exp) entries[key].exp = exp;
    }
    const dir = path.dirname(this.filePath);
    fs.mkdirSync(dir, { recursive: true });
    const tmp = `${this.filePath}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ entries }, null, 2), "utf8");
    fs.renameSync(tmp, this.filePath);
  }

  _enqueue(fn) {
    const run = this._queue.then(fn, fn);
    this._queue = run.then(() => undefined, () => undefined);
    return run;
  }

  _alive(key) {
    const exp = this.exp.get(key);
    if (exp && Date.now() > exp) {
      this.map.delete(key);
      this.exp.delete(key);
      return false;
    }
    return this.map.has(key);
  }

  async get(key) {
    if (!this._alive(key)) return null;
    return this.map.get(key);
  }

  async put(key, value, opts = {}) {
    return this._enqueue(async () => {
      this.map.set(key, value);
      if (opts.expirationTtl) this.exp.set(key, Date.now() + opts.expirationTtl * 1000);
      else this.exp.delete(key);
      this._persistSync();
    });
  }

  async delete(key) {
    return this._enqueue(async () => {
      this.map.delete(key);
      this.exp.delete(key);
      this._persistSync();
    });
  }

  async list({ prefix = "" } = {}) {
    const keys = [];
    for (const name of this.map.keys()) {
      if (name.startsWith(prefix) && this._alive(name)) keys.push({ name });
    }
    return { keys, list_complete: true };
  }
}
