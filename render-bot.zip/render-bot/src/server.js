/**
 * Node HTTP server for Render: binds 0.0.0.0:$PORT and adapts
 * IncomingMessage/ServerResponse to the fetch-style handleRequest.
 *
 * Start:  PORT=10000 TELEGRAM_TOKEN=... WEBHOOK_SECRET=... npm start
 */
import http from "node:http";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

import { FileKV } from "./file-kv.js";
import { handleRequest, MemoryCache } from "./index.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_FAV_PATH = path.resolve(__dirname, "../data/fav.json");

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks);
}

export async function toFetchRequest(req) {
  const host = req.headers.host || "localhost";
  const protoHeader = req.headers["x-forwarded-proto"];
  const proto = (Array.isArray(protoHeader) ? protoHeader[0] : protoHeader) || "http";
  const url = `${proto}://${host}${req.url}`;
  const headers = new Headers();
  for (const [key, value] of Object.entries(req.headers)) {
    if (value == null) continue;
    headers.set(key, Array.isArray(value) ? value.join(", ") : value);
  }
  const method = req.method || "GET";
  const init = { method, headers };
  if (method !== "GET" && method !== "HEAD") {
    init.body = await readBody(req);
    // Required by Node's fetch Request when a body is present.
    init.duplex = "half";
  }
  return new Request(url, init);
}

export async function sendFetchResponse(res, response) {
  const headers = {};
  response.headers.forEach((value, key) => {
    headers[key] = value;
  });
  const buf = Buffer.from(await response.arrayBuffer());
  res.writeHead(response.status, headers);
  res.end(buf);
}

export function createAppEnv(env = process.env, kv) {
  return {
    TELEGRAM_TOKEN: env.TELEGRAM_TOKEN || "",
    WEBHOOK_SECRET: env.WEBHOOK_SECRET || "",
    TELEGRAM_API_BASE: env.TELEGRAM_API_BASE || "",
    SCHEDULE_NOW: env.SCHEDULE_NOW || "",
    FAV: kv,
  };
}

/**
 * @param {object} [overrides]
 * @param {number} [overrides.port]  0 = ephemeral port
 * @param {NodeJS.ProcessEnv} [overrides.env]
 * @param {string} [overrides.kvPath]
 * @param {object} [overrides.cache]
 */
export function startServer(overrides = {}) {
  const env = { ...process.env, ...(overrides.env || {}) };
  const port = overrides.port !== undefined ? overrides.port : Number(env.PORT || 10000);
  const kvPath = overrides.kvPath || env.FAV_PATH || DEFAULT_FAV_PATH;
  const kv = overrides.kv || new FileKV(kvPath);
  const cache = overrides.cache || new MemoryCache();
  const appEnv = createAppEnv(env, kv);

  const server = http.createServer(async (req, res) => {
    try {
      const request = await toFetchRequest(req);
      const response = await handleRequest(request, appEnv, { cache });
      await sendFetchResponse(res, response);
    } catch (err) {
      console.error(JSON.stringify({
        message: "request failed",
        error: err && err.message ? err.message : String(err),
      }));
      if (!res.headersSent) {
        res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("internal error");
      }
    }
  });

  return new Promise((resolve, reject) => {
    const onError = (err) => reject(err);
    server.once("error", onError);
    server.listen(port, "0.0.0.0", () => {
      server.removeListener("error", onError);
      const addr = server.address();
      const actualPort = typeof addr === "object" && addr ? addr.port : port;
      resolve({
        server,
        port: actualPort,
        url: `http://127.0.0.1:${actualPort}`,
        kv,
        cache,
        close() {
          return new Promise((resClose, rejClose) => {
            server.close((e) => (e ? rejClose(e) : resClose()));
          });
        },
      });
    });
  });
}

function isMain() {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return import.meta.url === pathToFileURL(path.resolve(entry)).href;
  } catch {
    return false;
  }
}

if (isMain()) {
  startServer()
    .then(({ port }) => {
      console.log(`raspisanie-bot listening on 0.0.0.0:${port}`);
    })
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
