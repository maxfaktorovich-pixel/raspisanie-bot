/**
 * Telegram webhook bot for the gymnasium schedule, adapted from the
 * Cloudflare Worker in ../cf-worker for a Node HTTP server on Render.
 *
 * Env: TELEGRAM_TOKEN, WEBHOOK_SECRET, optional TELEGRAM_API_BASE,
 * optional SCHEDULE_NOW (ISO timestamp, tests only).
 *
 * This process must never register a Telegram webhook URL. Switching the bot
 * from the existing polling instance is a separate, manual step.
 */

import {
  handleMessage,
  getNika,
  nowNsk,
  dowOf,
  changesMessage,
  listSubscribedClasses,
  MemoryCache,
} from "./schedule.js";

export { handleMessage, getNika, nowNsk, MemoryCache };
export {
  MemoryKV,
  parseNikaSource,
  fromNsk,
  helpText,
  startText,
} from "./schedule.js";

const DEFAULT_TG_ORIGIN = "https://api.telegram.org";

export function telegramApiUrl(token, method, env = {}) {
  const origin = String(env.TELEGRAM_API_BASE || process.env.TELEGRAM_API_BASE || DEFAULT_TG_ORIGIN).replace(
    /\/+$/,
    "",
  );
  return `${origin}/bot${token}/${method}`;
}

/** Hash both strings, then compare — avoids leaking length via timing. */
export async function secretsEqual(provided, expected) {
  const enc = new TextEncoder();
  const [a, b] = await Promise.all([
    crypto.subtle.digest("SHA-256", enc.encode(provided ?? "")),
    crypto.subtle.digest("SHA-256", enc.encode(expected ?? "")),
  ]);
  const A = new Uint8Array(a);
  const B = new Uint8Array(b);
  if (typeof crypto.subtle.timingSafeEqual === "function") {
    return crypto.subtle.timingSafeEqual(A, B);
  }
  let diff = 0;
  for (let i = 0; i < A.length; i++) diff |= A[i] ^ B[i];
  return diff === 0;
}

function pathSecretAfter(pathname, prefix, expected) {
  if (!expected) return false;
  if (!pathname.startsWith(prefix)) return false;
  const got = decodeURIComponent(pathname.slice(prefix.length).replace(/\/+$/, ""));
  return got.length > 0 && got === expected;
}

export function splitTelegramHtml(html) {
  if (html.length <= 4000) return [html];
  const chunks = [];
  const buf = [];
  let size = 0;
  for (const para of html.split("\n")) {
    if (size + para.length + 1 > 3900 && buf.length) {
      chunks.push(buf.join("\n"));
      buf.length = 0;
      size = 0;
    }
    buf.push(para);
    size += para.length + 1;
  }
  if (buf.length) chunks.push(buf.join("\n"));
  return chunks;
}

export async function sendTelegram(token, chatId, html, fetchFn = globalThis.fetch, env = {}) {
  const chunks = splitTelegramHtml(html);
  for (const ch of chunks) {
    const params = {
      chat_id: chatId,
      text: ch,
      parse_mode: "HTML",
      disable_web_page_preview: true,
    };
    let res = await fetchFn(telegramApiUrl(token, "sendMessage", env), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    });
    let data = null;
    try {
      data = await res.json();
    } catch {
      data = null;
    }
    if (data && !data.ok && String(data.description || "").toLowerCase().includes("parse")) {
      params.parse_mode = undefined;
      params.text = ch.replace(/<[^>]+>/g, "");
      await fetchFn(telegramApiUrl(token, "sendMessage", env), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      });
    }
  }
}

function resolveToday(env, opts = {}) {
  if (opts.today) return nowNsk(new Date(opts.today));
  const raw = env?.SCHEDULE_NOW || opts.scheduledTime;
  if (raw != null && raw !== "") return nowNsk(new Date(raw));
  return nowNsk(new Date());
}

export async function processUpdate(update, env, opts = {}) {
  const msg = update?.message;
  const text = msg?.text;
  const chatId = msg?.chat?.id;
  if (!text || chatId == null) return;
  const fetchFn = opts.fetch ?? globalThis.fetch;
  const cache = opts.cache ?? globalThis.caches?.default;
  try {
    const nika = await getNika({ cache, fetch: fetchFn, nika: opts.nika });
    const reply = await handleMessage(text, {
      chatId,
      nika,
      kv: env.FAV,
      today: resolveToday(env, opts),
    });
    await sendTelegram(env.TELEGRAM_TOKEN, chatId, reply, fetchFn, env);
  } catch (err) {
    console.error(JSON.stringify({
      message: "handler failed",
      error: err && err.message ? err.message : String(err),
    }));
    try {
      await sendTelegram(
        env.TELEGRAM_TOKEN,
        chatId,
        "Не получилось получить расписание, попробуйте ещё раз.",
        fetchFn,
        env,
      );
    } catch {
      // ignore secondary failure
    }
  }
}

export async function runDailyChanges(env, opts = {}) {
  const fetchFn = opts.fetch ?? globalThis.fetch;
  const cache = opts.cache ?? globalThis.caches?.default;
  const today = resolveToday(env, opts);
  if (dowOf(today) === 7) {
    return { skipped: "sunday", sent: 0 };
  }
  if (!env.FAV) {
    return { skipped: "no-kv", sent: 0 };
  }
  const nika = await getNika({ cache, fetch: fetchFn, nika: opts.nika });
  const subs = await listSubscribedClasses(env.FAV);
  let sent = 0;
  for (const { className, chats } of subs) {
    const text = await changesMessage(nika, className, today);
    if (!text) continue;
    for (const chatId of chats) {
      await sendTelegram(env.TELEGRAM_TOKEN, chatId, text, fetchFn, env);
      sent += 1;
    }
  }
  return { skipped: null, sent };
}

async function authorizePath(request, env, prefix) {
  const url = new URL(request.url);
  const secret = env.WEBHOOK_SECRET || "";
  const pathOk = pathSecretAfter(url.pathname, prefix, secret);
  const header = request.headers.get("X-Telegram-Bot-Api-Secret-Token") ||
    request.headers.get("X-Cron-Secret") ||
    "";
  if (!secret || !pathOk) return false;
  if (header) return secretsEqual(header, secret);
  return true;
}

export async function handleWebhook(request, env, ctx, opts = {}) {
  const secret = env.WEBHOOK_SECRET || "";
  const url = new URL(request.url);
  const pathOk = pathSecretAfter(url.pathname, "/webhook/", secret);
  const header = request.headers.get("X-Telegram-Bot-Api-Secret-Token") || "";
  const headerOk = await secretsEqual(header, secret);
  if (!secret || !pathOk || !headerOk) {
    return new Response("unauthorized", { status: 401 });
  }
  if (request.method !== "POST") {
    return new Response("method not allowed", { status: 405 });
  }
  if (!env.TELEGRAM_TOKEN) {
    return new Response("misconfigured", { status: 500 });
  }
  let update;
  try {
    update = await request.json();
  } catch {
    return new Response("ok", { status: 200 });
  }
  const work = processUpdate(update, env, opts);
  if (ctx && typeof ctx.waitUntil === "function") ctx.waitUntil(work);
  else await work;
  return new Response("ok", { status: 200 });
}

export async function handleCron(request, env, opts = {}) {
  const ok = await authorizePath(request, env, "/cron/");
  if (!ok) {
    return new Response("unauthorized", { status: 401 });
  }
  if (request.method !== "GET" && request.method !== "POST") {
    return new Response("method not allowed", { status: 405 });
  }
  if (!env.TELEGRAM_TOKEN) {
    return new Response("misconfigured", { status: 500 });
  }
  const result = await runDailyChanges(env, opts);
  return new Response(JSON.stringify({ message: "daily changes", ...result }), {
    status: 200,
    headers: { "Content-Type": "application/json; charset=utf-8" },
  });
}

export function healthResponse() {
  return new Response("raspisanie-bot ok", {
    status: 200,
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  });
}

export async function handleRequest(request, env, opts = {}) {
  const url = new URL(request.url);
  if ((url.pathname === "/" || url.pathname === "") && request.method === "GET") {
    return healthResponse();
  }
  if (url.pathname.startsWith("/webhook/")) {
    return handleWebhook(request, env, opts.ctx, opts);
  }
  if (url.pathname.startsWith("/cron/")) {
    return handleCron(request, env, opts);
  }
  return new Response("not found", { status: 404 });
}
