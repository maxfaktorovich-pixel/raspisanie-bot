/**
 * Local tests for the Render webhook server.
 * Real fetches go to raspisanie.nikasoft.ru.
 * Telegram API is stubbed via TELEGRAM_API_BASE — no setWebhook, no real token.
 */
import assert from "node:assert/strict";
import fs from "node:fs";
import http from "node:http";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { after, before, describe, it } from "node:test";

import { FileKV } from "../src/file-kv.js";
import { startServer } from "../src/server.js";
import { fromNsk, parseNikaSource } from "../src/index.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WEBHOOK_SECRET = "test-webhook-secret-value";
const FAKE_TOKEN = "000000000:TESTTOKEN_NOT_REAL";
const CHAT = 999001;
// Saturday 21 Nov 2026, 07:00 Novosibirsk — 5а has replacements that day.
const SCHEDULE_NOW = "2026-11-21T07:00:00+07:00";

function startTelegramStub() {
  const sent = [];
  const server = http.createServer(async (req, res) => {
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    let body = {};
    try {
      body = JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
    } catch {
      body = {};
    }
    sent.push({ method: req.method, url: req.url, body });
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ ok: true, result: { message_id: 1 } }));
  });
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const port = server.address().port;
      resolve({
        sent,
        url: `http://127.0.0.1:${port}`,
        close: () => new Promise((resClose, rejClose) => {
          server.close((err) => (err ? rejClose(err) : resClose()));
        }),
      });
    });
  });
}

async function httpCall(baseUrl, { method = "GET", path: p = "/", headers = {}, body } = {}) {
  const res = await fetch(`${baseUrl}${p}`, {
    method,
    headers,
    body: body !== undefined ? (typeof body === "string" ? body : JSON.stringify(body)) : undefined,
  });
  const text = await res.text();
  return { status: res.status, text, headers: res.headers };
}

describe("render webhook server", () => {
  let tmpDir;
  let stub;
  let bot;
  const sourceFiles = [
    "src/index.js",
    "src/server.js",
    "src/schedule.js",
    "src/file-kv.js",
    "package.json",
    "render.yaml",
    "README.ru.md",
    ".env.example",
    "test/server.test.mjs",
  ];

  before(async () => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "render-bot-"));
    stub = await startTelegramStub();
    bot = await startServer({
      port: 0,
      kvPath: path.join(tmpDir, "fav.json"),
      env: {
        TELEGRAM_TOKEN: FAKE_TOKEN,
        WEBHOOK_SECRET,
        TELEGRAM_API_BASE: stub.url,
        SCHEDULE_NOW,
        PORT: "0",
      },
    });
  });

  after(async () => {
    if (bot) await bot.close();
    if (stub) await stub.close();
    if (tmpDir) fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it("GET / returns 200 health text", async () => {
    const res = await httpCall(bot.url, { path: "/" });
    assert.equal(res.status, 200);
    assert.match(res.text, /raspisanie-bot ok/);
  });

  it("POST /schedule 5а replies with Saturday lessons (Telegram stubbed)", async () => {
    stub.sent.length = 0;
    const res = await httpCall(bot.url, {
      method: "POST",
      path: `/webhook/${WEBHOOK_SECRET}`,
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token": WEBHOOK_SECRET,
      },
      body: {
        update_id: 1,
        message: { message_id: 1, chat: { id: CHAT }, text: "/schedule 5а" },
      },
    });
    assert.equal(res.status, 200);
    assert.equal(res.text, "ok");
    assert.equal(stub.sent.length, 1);
    assert.match(stub.sent[0].url, /\/bot000000000:TESTTOKEN_NOT_REAL\/sendMessage$/);
    const text = stub.sent[0].body.text;
    assert.equal(stub.sent[0].body.chat_id, CHAT);
    assert.equal(stub.sent[0].body.parse_mode, "HTML");
    assert.match(text, /5а/);
    assert.match(text, /суббот/i);
    assert.match(text, /21 ноября/);
    assert.match(text, /8:30/);
    assert.match(text, /9:25|10:25|11:25|12:25/);
  });

  it("POST /tomorrow 5а replies with Sunday (no lessons) after pinned Saturday", async () => {
    stub.sent.length = 0;
    const res = await httpCall(bot.url, {
      method: "POST",
      path: `/webhook/${encodeURIComponent(WEBHOOK_SECRET)}`,
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token": WEBHOOK_SECRET,
      },
      body: {
        update_id: 2,
        message: { message_id: 2, chat: { id: CHAT }, text: "/tomorrow 5а" },
      },
    });
    assert.equal(res.status, 200);
    assert.equal(stub.sent.length, 1);
    const text = stub.sent[0].body.text;
    assert.match(text, /5а/);
    assert.match(text, /воскресень/i);
  });

  it("wrong webhook secret returns 401 and does not call Telegram", async () => {
    stub.sent.length = 0;
    const badHeader = await httpCall(bot.url, {
      method: "POST",
      path: `/webhook/${WEBHOOK_SECRET}`,
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token": "nope",
      },
      body: { message: { chat: { id: 1 }, text: "/start" } },
    });
    assert.equal(badHeader.status, 401);

    const badPath = await httpCall(bot.url, {
      method: "POST",
      path: "/webhook/other-secret",
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token": WEBHOOK_SECRET,
      },
      body: { message: { chat: { id: 1 }, text: "/start" } },
    });
    assert.equal(badPath.status, 401);
    assert.equal(stub.sent.length, 0);
  });

  it("GET/POST /cron with the secret runs daily changes; wrong secret is 401", async () => {
    stub.sent.length = 0;
    const denied = await httpCall(bot.url, { method: "GET", path: "/cron/wrong" });
    assert.equal(denied.status, 401);

    // Subscribe 5а, then Saturday cron should send replacements.
    const sub = await httpCall(bot.url, {
      method: "POST",
      path: `/webhook/${WEBHOOK_SECRET}`,
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token": WEBHOOK_SECRET,
      },
      body: {
        message: { chat: { id: CHAT }, text: "/subscribe 5а" },
      },
    });
    assert.equal(sub.status, 200);
    assert.equal(stub.sent.length, 1);
    assert.match(stub.sent[0].body.text, /7:45/);
    stub.sent.length = 0;

    const cron = await httpCall(bot.url, { method: "GET", path: `/cron/${WEBHOOK_SECRET}` });
    assert.equal(cron.status, 200);
    const payload = JSON.parse(cron.text);
    assert.equal(payload.sent, 1);
    assert.equal(stub.sent.length, 1);
    assert.match(stub.sent[0].body.text, /Замены|замена|5а/i);
  });

  it("FileKV persists favorites across reload", async () => {
    const filePath = path.join(tmpDir, "persist.json");
    const a = new FileKV(filePath);
    await a.put("fav:1", "5а");
    await a.put("pending:1", "myclass", { expirationTtl: 600 });
    const b = new FileKV(filePath);
    assert.equal(await b.get("fav:1"), "5а");
    assert.equal(await b.get("pending:1"), "myclass");
    const listed = await b.list({ prefix: "fav:" });
    assert.equal(listed.keys.length, 1);
    assert.equal(listed.keys[0].name, "fav:1");
  });

  it("parses var NIKA= without eval", () => {
    const src = 'var NIKA={"CLASSES":{"023":"5а"}};\n';
    assert.equal(parseNikaSource(src).CLASSES["023"], "5а");
    void fromNsk;
  });

  it("source has no hardcoded bot token and no setWebhook", () => {
    const root = path.resolve(__dirname, "..");
    for (const rel of sourceFiles) {
      const txt = fs.readFileSync(path.join(root, rel), "utf8");
      assert.ok(!txt.includes("885922" + "1071"), `token id leaked in ${rel}`);
      assert.ok(!txt.includes("AAFgN2jv" + "UJX4FxljkNWV18YfhuJzHP8kvPc"), `token leaked in ${rel}`);
      if (rel.startsWith("src/")) {
        assert.doesNotMatch(txt, /setWebhook/);
      }
    }
  });
});
